Used this for the java help

https://github.com/adamjshook/mapreducepatterns/blob/master/MRDP/src/main/java/mrdp/ch5/ReduceSideJoinDriver.java