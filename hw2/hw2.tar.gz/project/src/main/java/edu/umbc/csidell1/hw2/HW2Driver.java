package edu.umbc.csidell1.hw2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class HW2Driver extends Configured implements Tool {

	public static void main(String[] args) throws Exception {
		System.exit(ToolRunner.run(new Configuration(), new HW2Driver(), args));
	}

	@Override
	public int run(String[] args) throws Exception {

		if (args.length != 3) {
			System.err.println("Usage: <tweets> <users> <output>");
			System.exit(2);
		}
		
		String[] otherArgs = new GenericOptionsParser(getConf(), args)
		.getRemainingArgs();

		Job job = Job.getInstance(getConf(), "Homework 2");
		job.setJarByClass(HW2Driver.class);
		
		MultipleInputs.addInputPath(job, new Path(otherArgs[0]),
				TextInputFormat.class, TweetsMapper.class);
		MultipleInputs.addInputPath(job, new Path(otherArgs[1]),
				TextInputFormat.class, UsersMapper.class);
		
		job.setReducerClass(HW2Reducer.class);
		
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[2]));

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		return job.waitForCompletion(true) ? 0 : 1;
	}

}
