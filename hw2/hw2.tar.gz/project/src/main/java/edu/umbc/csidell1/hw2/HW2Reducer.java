package edu.umbc.csidell1.hw2;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class HW2Reducer extends Reducer<Text, Text, Object, Object> {

	private ArrayList<Text> listA = new ArrayList<Text>();
	private ArrayList<Text> listB = new ArrayList<Text>();
	
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		for (Text t: values)
		{
			if (t.charAt(0) == 'u') {
				listA.add(new Text(t.toString().substring(1)));
			} else if (t.charAt('0') == 't') {
				listB.add(new Text(t.toString().substring(1)));
			}
		}
		
		DoTheJoin(context);
	}
	
	private void DoTheJoin(Context context) throws IOException,
	InterruptedException {
		if (!listA.isEmpty() && !listB.isEmpty()) {
			for (Text A : listA) {
				for (Text B : listB) {
					context.write(A, B);
				}
			}
		}
	}
}
