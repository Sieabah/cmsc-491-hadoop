package edu.umbc.csidell1.hw2;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class UsersMapper extends Mapper<Object, Text, Object, Object> {

	@Override
	public void map(Object key, Text value, Context context)
			throws IOException, InterruptedException {
		
		//user_id screen_name created_at num_followers
		String[] line=value.toString().split("\t"); 
		
		if(Long.parseLong(line[3]) >= 200000)
			context.write(new Text(line[0]), new Text("u"+line[3]));
	}
}
