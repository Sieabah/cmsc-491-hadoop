package edu.umbc.csidell1.hw2;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TweetsMapper extends Mapper<Object, Text, Object, Object> {

	@Override
	public void map(Object key, Text value, Context context)
			throws IOException, InterruptedException {
		//tweet_id user_id date source text
		String[] line=value.toString().split("\t");
		
		context.write(new Text(line[1]), new Text("t"+value.toString()));
	}
}
