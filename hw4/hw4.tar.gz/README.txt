Create table using:
create "tweets", "metadata", "messages"

Resources Used:
StackOverflow
TutorialsPoint: http://www.tutorialspoint.com/hbase/
Apache HBase book: http://hbase.apache.org/book.html
