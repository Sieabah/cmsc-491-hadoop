Used these resources
https://flume.apache.org/FlumeUserGuide.html
https://sqoop.apache.org/docs/1.4.1-incubating/SqoopUserGuide.html#_literal_sqoop_import_literal
