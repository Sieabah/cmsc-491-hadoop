package org.csidell;

/*
 * HW1
 * csidell-1
 * 
 * Map lines from file to specific words
 */

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class WordCountMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, IntWritable>
{
      private final static IntWritable one = new IntWritable(1);
      private Text word = new Text();
    
      public void map(LongWritable key, Text value, OutputCollector<Text, IntWritable> output, Reporter reporter) throws IOException
      {
            //Get line
            String line = value.toString();
            
            //Replace the symbols and sort of 'tokenize' words
            line = line.toLowerCase();
            line = line.replaceAll("'", "");
            line = line.replaceAll("[^a-zA-Z]", " ");
            
            //Break apart each word
            StringTokenizer tokenizer = new StringTokenizer(line);
         
            //While words exist
            while (tokenizer.hasMoreTokens())
            {
            	//Get word and collect
            	word.set(tokenizer.nextToken());
            	output.collect(word, one);
            }
       }
}